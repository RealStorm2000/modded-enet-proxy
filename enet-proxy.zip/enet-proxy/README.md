How to use
PC: 1. Disable real time protection in windows defender
2. Download the release by pressing code, download zip
3. Extract to your desktop or downloads
4. Run
5. If not working read the readme.md